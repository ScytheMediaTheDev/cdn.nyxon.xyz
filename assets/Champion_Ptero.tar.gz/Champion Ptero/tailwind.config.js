const colors = require('tailwindcss/colors');

const gray = {
    50: withOpacity('--color-50'),
    100: withOpacity('--color-100'),
    200: withOpacity('--color-200'),
    300: withOpacity('--color-300'),
    400: withOpacity('--color-400'),
    500: withOpacity('--color-500'),
    600: withOpacity('--color-600'),
    700: withOpacity('--color-700'),
    800: withOpacity('--color-800'),
    900: withOpacity('--color-900')
};

const neutral = {
    50: withOpacity('--color-50'),
    100: withOpacity('--color-100'),
    200: withOpacity('--color-200'),
    300: withOpacity('--color-300'),
    400: withOpacity('--color-400'),
    500: withOpacity('--color-500'),
    600: withOpacity('--color-600'),
    700: withOpacity('--color-700'),
    800: withOpacity('--color-800'),
    900: withOpacity('--color-900')
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
            },
            colors: {
                black: '#131a20',
                // "primary" and "neutral" are deprecated, prefer the use of "blue" and "gray"
                // in new code.
                primary: colors.blue,
                gray: gray,
                neutral: neutral,
                cyan: colors.cyan,
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ]
};

function withOpacity(variableName) {
    return ({ opacityValue }) => {
      if (opacityValue !== undefined) {
        return `rgba(var(${variableName}), ${opacityValue})`;
      }
      return `rgb(var(${variableName}))`;
    };
}