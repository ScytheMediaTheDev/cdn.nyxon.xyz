<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddDefaultThemeSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('theme_settings', function (Blueprint $table) {
            $table->id();
            $table->string('nav_type')->default('sidebar');
            $table->string('site_bg')->default('');
            $table->string('color_50')->default('245, 247, 250');
            $table->string('color_100')->default('233, 222, 222');
            $table->string('color_200')->default('109, 99, 131');
            $table->string('color_300')->default('158, 151, 173');
            $table->string('color_400')->default('174, 168, 177');
            $table->string('color_500')->default('96, 109, 123');
            $table->string('color_600')->default('30, 23, 45');
            $table->string('color_700')->default('30, 30, 51');
            $table->string('color_800')->default('25, 20, 37');
            $table->string('color_900')->default('25, 20, 37');
            $table->string('color_bttn_primary')->default('37, 99, 235');
            $table->string('color_bttn_secondary')->default('107, 114, 128');
            $table->string('color_bttn_danger')->default('220, 38, 38');
            $table->string('color_h_bttn_primary')->default('59, 130, 246');
            $table->string('color_h_bttn_secondary')->default('123, 135, 147');
            $table->string('color_h_bttn_danger')->default('239, 68, 68');
            $table->string('color_accent')->default('112, 90, 223');
            $table->string('color_box_border')->default('47, 47, 91');
            $table->timestamps();
        });

        DB::table('theme_settings')->insert(
            array(
                'nav_type' => 'sidebar',
            )
        );
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('theme_settings');
    }
};
