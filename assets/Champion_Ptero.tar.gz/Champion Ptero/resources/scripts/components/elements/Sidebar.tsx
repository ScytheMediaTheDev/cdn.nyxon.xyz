import { ServerIcon } from '@heroicons/react/solid';
import React from 'react';
import { useState, useEffect } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import styled from 'styled-components';
import tw, { theme } from 'twin.macro';
import routes from '@/routers/routes';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faServer, faCogs, faSignOutAlt, faUser, faTimes, faBars, faSearch } from '@fortawesome/free-solid-svg-icons';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import useEventListener from '@/plugins/useEventListener';
import SearchModal from '@/components/dashboard/search/SearchModal';
import http from '@/api/http';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';

const StyledSidebar = styled.div`
    ${tw`flex flex-col z-[49] transition-all duration-300 ease-in-out py-3 bg-neutral-600 fixed md:sticky top-0 overflow-y-auto h-screen w-full md:w-56`};

    .sidebar-toggle {
        ${tw`flex md:hidden fixed justify-center text-white items-center rounded-full text-[32px] cursor-pointer font-bold z-[49] w-16 h-16 bottom-[3%] right-[5%]`}
        background-color: rgb(var(--accent-color));
    }

    & > a:not(.sidebar-logo), & .account-expandable {
        ${tw`inline relative items-center px-4 py-3 text-neutral-300 no-underline transition-all duration-150 ease-in-out`};

        & > svg {
            width: 1.1rem !important;
            height: 1.1rem !important;
        }

        & > span {
            ${tw`text-neutral-100 ml-2 inline`};
        }

        &:hover {
            ${tw`text-neutral-100 bg-neutral-700 rounded-md`};
        }

        &.active, &.account-expandable.expanded {
           ${tw`bg-neutral-700 rounded-r-md`};

           & > svg {
            ${tw`text-neutral-100`};
           }
        }

        & .account-sublinks a.active {
            ${tw`bg-neutral-600 rounded-r-md`};
        }

        &.active:before, & .account-sublinks a.active:before  {
            ${tw`block absolute left-0 top-0 bottom-0 m-auto w-[4px] h-[40px]`};

            content: "";
            background: rgb(var(--accent-color));
            border-radius: 0px 5px 5px 0px;
            box-shadow: 1.5px 0px 10px 0px ${theme`colors.blue.500`.toString()};
        }

        &.account-expandable.active:before, & .account-sublinks a.active:before {
            ${tw`bottom-auto`};
        }
    }
`;

const StyleAccountExpand = styled.div`
    & > ul {
        ${tw`flex flex-col max-h-0 overflow-hidden`};
        transition: all 0.3s ease-out;

        & > a {
            ${tw`p-3 cursor-pointer`};
            transition: all 0.3s ease-in-out;

            &:hover {
                ${tw`bg-neutral-600 rounded-md`};
                transition: all 0.3s ease-in-out;
            }
        }

        &.account-sublinks {
            ${tw`mt-2`}
            max-height: 300px;
            transition: all 0.3s ease-out;
        }
    }
`;

const Sidebar = ({ children }: { children?: React.ReactNode }): JSX.Element => {
    const name = useStoreState((state: ApplicationStore) => state.settings.data!.name);
    const logo = useStoreState((state: ApplicationStore) => state.settings.data!.logo);
    const location = useLocation();

    const [isLoggingOut, setIsLoggingOut] = useState(false);
    const [sidebar, setSidebar] = useState(false);
    const [visible, setVisible] = useState(false);
    const [accountExpanded, setAccountExpanded] = useState(false);

    const toggleSidebar = () => {
        setSidebar((sidebar) => !sidebar);
    }

    const onTriggerLogout = () => {
        setIsLoggingOut(true);
        http.post('/auth/logout').finally(() => {
            // @ts-expect-error this is valid
            window.location = '/';
        });
    };

    useEventListener('keydown', (e: KeyboardEvent) => {
        if (['input', 'textarea'].indexOf(((e.target as HTMLElement).tagName || 'input').toLowerCase()) < 0) {
            if (!visible && e.metaKey && e.key.toLowerCase() === '/') {
                setVisible(true);
            }
        }
    });

    useEffect(() => {
        if(sidebar == true)
            toggleSidebar();

        if(accountExpanded && !location.pathname.includes('/account'))
            setAccountExpanded(false);
        else if(location.pathname.includes('/account'))
            setAccountExpanded(true);
    }, [location]);

    return (
        <div className={'sidebar-navigation absolute md:relative'}>
            <StyledSidebar className={sidebar == true ? 'ml-0' : 'ml-[-200%] md:ml-0'}>
                <SpinnerOverlay visible={isLoggingOut} />
                <span onClick={toggleSidebar} className={'sidebar-toggle'}>
                    {
                        sidebar == true ? <FontAwesomeIcon icon={faTimes} /> : <FontAwesomeIcon icon={faBars} />
                    }
                </span>

                <div className={'mx-auto mb-4'}>
                    <Link to={'/'}>
                        <img className={'max-w-[256px] md:max-w-full h-12'} src={logo || 'https://cdn.pterodactyl.io/logos/new/pterodactyl_logo_transparent.png'} />
                    </Link>
                </div>

                <NavLink to={'/'} exact>
                    <FontAwesomeIcon icon={faServer} /> <span>Servers</span>
                </NavLink>

                {children}
                <p className={'text-gray-200 px-3.5 py-2 font-bold text-sm'}>Other</p>
                <NavLink key={'/account'} to={'/account'} exact={true} className={`account-expandable ${accountExpanded == true ? 'expanded' : ''}`}>
                    <>
                        <FontAwesomeIcon icon={faUser} />
                        <span>Account</span>
                    </>
                    <StyleAccountExpand>
                        <ul className={accountExpanded == true ? 'account-sublinks' : ''}>
                            <NavLink key={'/account/api'} to={'/account/api'} exact={true}>
                                API Credentials
                            </NavLink>
                            <NavLink key={'/account/ssh'} to={'/account/ssh'} exact={true}>
                                SSH Keys
                            </NavLink>
                            <NavLink key={'/account/activity'} to={'/account/activity'} exact={true}>
                                Activity
                            </NavLink>
                        </ul>
                    </StyleAccountExpand>
                </NavLink>
                <a href={'/admin'} rel={'noreferrer'}>
                    <FontAwesomeIcon icon={faCogs} />
                    <span>Admin</span>
                </a>
                {visible && <SearchModal appear visible={visible} onDismissed={() => setVisible(false)} />}
                <a className={'cursor-pointer'} rel={'noreferrer'} onClick={() => setVisible(true)}>
                    <FontAwesomeIcon icon={faSearch} />
                    <span>Search</span>
                </a>
                <a href="" onClick={onTriggerLogout}>
                    <FontAwesomeIcon icon={faSignOutAlt} />
                    <span>Logout</span>
                </a>
            </StyledSidebar>
        </div>
    );
};

export default Sidebar;