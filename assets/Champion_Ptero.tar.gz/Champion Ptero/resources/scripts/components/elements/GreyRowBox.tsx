import styled from 'styled-components/macro';
import tw from 'twin.macro';

export default styled.div<{ $hoverable?: boolean }>`
    ${tw`flex rounded-lg no-underline text-neutral-200 items-center bg-neutral-700 p-4 border border-transparent transition-colors duration-150 overflow-hidden`};

    ${(props) => props.$hoverable !== false && `&:hover {
        border-color: rgb(var(--boxes-hover-border));
    }`};

    & .icon {
        ${tw`rounded-md flex items-center justify-center bg-neutral-600 p-3`};
    }
`;
