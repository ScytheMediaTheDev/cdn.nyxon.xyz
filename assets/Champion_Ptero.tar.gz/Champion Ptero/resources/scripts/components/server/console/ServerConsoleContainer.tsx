import React, { memo } from 'react';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import isEqual from 'react-fast-compare';
import Spinner from '@/components/elements/Spinner';
import Features from '@feature/Features';
import Console from '@/components/server/console/Console';
import StatGraphs from '@/components/server/console/StatGraphs';
import PowerButtons from '@/components/server/console/PowerButtons';
import ServerDetailsBlock from '@/components/server/console/ServerDetailsBlock';
import { Alert } from '@/components/elements/alert';
import tw, { TwStyle } from 'twin.macro';
import { ServerPowerState } from '@/api/server/getServerResourceUsage';
import CopyOnClick from '@/components/elements/CopyOnClick';
import { ip } from '@/lib/formatters';

export type PowerAction = 'start' | 'stop' | 'restart' | 'kill';

const ServerConsoleContainer = () => {
    const name = ServerContext.useStoreState((state) => state.server.data!.name);
    const description = ServerContext.useStoreState((state) => state.server.data!.description);
    const isInstalling = ServerContext.useStoreState((state) => state.server.isInstalling);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data!.isTransferring);
    const eggFeatures = ServerContext.useStoreState((state) => state.server.data!.eggFeatures, isEqual);
    const isNodeUnderMaintenance = ServerContext.useStoreState((state) => state.server.data!.isNodeUnderMaintenance);
    const serverId = ServerContext.useStoreState((state) => state.server.data!.id);
    const node = ServerContext.useStoreState((state) => state.server.data!.node);
    const status = ServerContext.useStoreState((state) => state.status.value);

    const allocation = ServerContext.useStoreState(state => {
        const match = state.server.data!.allocations.find(allocation => allocation.isDefault);

        return !match ? 'n/a' : `${match.alias || ip(match.ip)}:${match.port}`;
    });

    const getStatusColor = (serverStatus?: ServerPowerState | null): TwStyle | string => {
        switch (serverStatus) {
            case 'offline':
                return tw`bg-gray-200`;
            case 'starting':
                return tw`bg-yellow-400`;
            case 'stopping':
                return tw`bg-red-400`;
            case 'running':
                return tw`bg-green-500`;
            default:
                return tw`bg-gray-200`;
        }
    };

    const getStatusName = (serverStatus?: ServerPowerState | null): string => {
        switch (serverStatus) {
            case 'offline':
                return 'Offline';
            case 'starting':
                return 'Starting';
            case 'stopping':
                return 'Stopping';
            case 'running':
                return 'Online';
            default:
                return 'Offline';
        }
    };

    return (
        <ServerContentBlock title={'Console'}>
            {(isNodeUnderMaintenance || isInstalling || isTransferring) && (
                <Alert type={'warning'} className={'mb-4'}>
                    {isNodeUnderMaintenance
                        ? 'The node of this server is currently under maintenance and all actions are unavailable.'
                        : isInstalling
                        ? 'This server is currently running its installation process and most actions are unavailable.'
                        : 'This server is currently being transferred to another node and all actions are unavailable.'}
                </Alert>
            )}
            <div className={'grid grid-cols-12 gap-4 mb-4'}>
                <div className={'block col-span-12 sm:col-span-8 pr-4'}>
                    <p className={'flex flex-col sm:hidden font-header leading-tight text-xl text-gray-200 mb-2'}>
                        {name}
                        <CopyOnClick text={allocation}>
                            <span className={'w-fit sm:hidden text-neutral-50 text-base'}>{allocation}</span>
                        </CopyOnClick>
                    </p>
                    <h1 className={'hidden sm:flex items-baseline font-header text-2xl text-gray-50 leading-relaxed'}>
                        {name}
                        {!!description && (
                            <span className={'hidden sm:block text-neutral-200 ml-1 text-sm'}>/ {description}</span>
                        )}
                    </h1>
                    <p className={'font-header flex flex-wrap items-center text-sm text-gray-100 leading-relaxed'}>
                        <span className={'mr-2 rounded-full w-3 h-3 block'} css={getStatusColor(status)}></span>
                        {getStatusName(status)}<span className={'text-neutral-200 ml-1'}> / <span className={'text-gray-50'}>{node}</span> / <span className={'text-gray-50'}>{serverId}</span></span></p>
                </div>
                <div className={'hidden sm:block text-right col-span-4 self-end'}>
                    <CopyOnClick text={allocation}>
                        <p className={'text-right inline-flex flex-col border-r-4 pr-2.5 pt-1.5 border-blue-600 leading-none text-base font-bold'}>ADDRESS<p className={'text-gray-50 text-lg font-semibold'}>{allocation}</p></p>
                    </CopyOnClick>
                </div>
            </div>
            <ServerDetailsBlock className={'col-span-4 lg:col-span-1 order-last lg:order-none'} />
            <div className={'grid grid-cols-4 gap-2 sm:gap-4 mb-4 mt-4'}>
                <div className={'flex col-span-4'}>
                    <Spinner.Suspense>
                        <Console />
                    </Spinner.Suspense>
                </div>
                <Can action={['control.start', 'control.stop', 'control.restart']} matchAny>
                    <div className={'flex justify-end col-span-4'}>
                        <PowerButtons className={'space-x-2'} />
                    </div>
                </Can>
            </div>
            <div className={'grid grid-cols-1 md:grid-cols-3 gap-2 sm:gap-4'}>
                <Spinner.Suspense>
                    <StatGraphs />
                </Spinner.Suspense>
            </div>
            <Features enabled={eggFeatures} />
        </ServerContentBlock>
    );
};

export default memo(ServerConsoleContainer, isEqual);
