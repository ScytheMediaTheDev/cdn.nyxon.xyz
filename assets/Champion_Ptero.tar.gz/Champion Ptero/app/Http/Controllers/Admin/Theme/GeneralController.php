<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class GeneralController extends Controller
{
    /**
     * GeneralController constructor.
     */
    public function __construct(
        private AlertsMessageBag $alert
    ) {
    }

    /**
     * Return the general settings page.
     */
    public function index()
    {
        $settings = DB::table('theme_settings')->first();
        return view('admin.theme.index', ['settings' => $settings]);
    }

    /**
     * Update the theme settings in database.
     */
    public function update(Request $request)
    {
        $requestData = [
            'nav_type' => $request->nav_type,
            'site_bg' => $request->site_bg,
        ];

        $dataId = DB::table('theme_settings')->first()->id;
        DB::table('theme_settings')->where('id', '=', $dataId)->update($requestData);

        $this->alert->success('General settings have been successfully updated.')->flash();
        return redirect()->route('admin.theme');
    }
}
