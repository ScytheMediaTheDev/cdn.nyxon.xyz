<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Support\Facades\DB;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;

class ThemeController extends Controller
{
    public function themeSettings(): JsonResponse
    {
        $settings = DB::table('theme_settings')->first();
        return new JsonResponse(json_encode($settings), 200, [], null, true);
    }
}