import React, { memo, useEffect, useRef, useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEthernet, faHdd, faMemory, faMicrochip, faServer, faInfoCircle } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';
import { Server } from '@/api/server/getServer';
import getServerResourceUsage, { ServerPowerState, ServerStats } from '@/api/server/getServerResourceUsage';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import tw, { theme } from 'twin.macro';
import GreyRowBox from '@/components/elements/GreyRowBox';
import Spinner from '@/components/elements/Spinner';
import styled, { css } from 'styled-components/macro';
import isEqual from 'react-fast-compare';
import CopyOnClick from '@/components/elements/CopyOnClick';
import { breakpoint } from '@/theme';

// Determines if the current value is in an alarm threshold so we can show it in red rather
// than the more faded default style.
const isAlarmState = (current: number, limit: number): boolean => limit > 0 && current / (limit * 1024 * 1024) >= 0.9;

const IconDescription = styled.p<{ $alarm: boolean }>`
    ${tw`text-sm`};
    ${(props) => (props.$alarm ? tw`text-red-400` : tw`text-neutral-400`)};
`;

const StatusIndicatorBox = styled(GreyRowBox)<{ $status: ServerPowerState | undefined }>`
    ${tw`flex relative rounded-lg col-span-12 md:col-span-6`};
    ${css`
        background: linear-gradient(45deg, ${theme('colors.gray.700')} 80%, ${theme('colors.gray.600')} 20%);
    `};
    align-items: normal;

    .icon {
        display: none !important;
    }

    ${breakpoint('sm')`
        ${css`
            & {
                background: linear-gradient(45deg, ${theme('colors.gray.700')} 85%, ${theme('colors.gray.600')} 15%);
            }
            .icon {
                display: flex !important;
            }
        `}
    `};

    & .status-bar {
        ${tw`w-full bg-red-500 absolute left-0 bottom-0 z-20 opacity-50 transition-all duration-150`};
        height: 10px !important;

        ${({ $status }) =>
            !$status || $status === 'offline'
                ? tw`bg-red-500`
                : $status === 'running'
                ? tw`bg-green-500`
                : tw`bg-yellow-500`};
    }

    &:hover .status-bar {
        ${tw`opacity-75`};
    }
`;

type Timer = ReturnType<typeof setInterval>;

export default ({ server, className }: { server: Server; className?: string }) => {
    const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>;
    const [isSuspended, setIsSuspended] = useState(server.status === 'suspended');
    const [stats, setStats] = useState<ServerStats | null>(null);

    const getStats = () =>
        getServerResourceUsage(server.uuid)
            .then((data) => setStats(data))
            .catch((error) => console.error(error));

    useEffect(() => {
        setIsSuspended(stats?.isSuspended || server.status === 'suspended');
    }, [stats?.isSuspended, server.status]);

    useEffect(() => {
        // Don't waste a HTTP request if there is nothing important to show to the user because
        // the server is suspended.
        if (isSuspended) return;

        getStats().then(() => {
            interval.current = setInterval(() => getStats(), 30000);
        });

        return () => {
            interval.current && clearInterval(interval.current);
        };
    }, [isSuspended]);

    const alarms = { cpu: false, memory: false, disk: false };
    if (stats) {
        alarms.cpu = server.limits.cpu === 0 ? false : stats.cpuUsagePercent >= server.limits.cpu * 0.9;
        alarms.memory = isAlarmState(stats.memoryUsageInBytes, server.limits.memory);
        alarms.disk = server.limits.disk === 0 ? false : isAlarmState(stats.diskUsageInBytes, server.limits.disk);
    }

    const diskLimit = server.limits.disk !== 0 ? bytesToString(mbToBytes(server.limits.disk)) : 'Unlimited';
    const memoryLimit = server.limits.memory !== 0 ? bytesToString(mbToBytes(server.limits.memory)) : 'Unlimited';
    const cpuLimit = server.limits.cpu !== 0 ? server.limits.cpu + ' %' : 'Unlimited';

    return (
        <StatusIndicatorBox as={Link} to={`/server/${server.id}`} className={className} $status={stats?.status}>
            <div css={tw`flex w-max justify-between flex-col`}>
                <div css={tw`flex mb-2`}>
                    <div>
                        <p css={tw`flex flex-col items-baseline text-lg text-gray-100 break-words font-medium`}>{server.name}
                            {!!server.description && (
                                <span className={'text-gray-200 text-sm hidden md:flex mb-1 -mt-0.5'}>
                                    {server.description}
                                </span>
                            )}
                        </p>
                        <div css={tw`flex`}>
                            <span className={'text-neutral-200 text-sm'}>
                                <span className={'text-gray-50'}>{server.node}</span> / <span className={'text-gray-50'}>{server.id}</span> / <span className={'text-gray-50'}>
                                    {server.allocations
                                        .filter((alloc) => alloc.isDefault)
                                        .map((allocation) => (
                                            <CopyOnClick text={allocation.ip + allocation.port.toString()}>
                                                <React.Fragment key={allocation.ip + allocation.port.toString()}>
                                                    {allocation.alias || ip(allocation.ip)}:{allocation.port}
                                                </React.Fragment>
                                            </CopyOnClick>
                                        ))}
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
                <div css={tw`hidden gap-x-8 gap-y-4 mb-3 sm:flex items-baseline flex-wrap`}>
                    {!stats || isSuspended ? (
                        isSuspended ? (
                            <div css={tw`flex-1 text-center`}>
                                <span css={tw`bg-red-500 rounded px-2 py-1 text-red-100 text-xs`}>
                                    {server.status === 'suspended' ? 'Suspended' : 'Connection Error'}
                                </span>
                            </div>
                        ) : server.isTransferring || server.status ? (
                            <div css={tw`flex-1 text-center`}>
                                <span css={tw`bg-neutral-500 rounded px-2 py-1 text-neutral-100 text-xs`}>
                                    {server.isTransferring
                                        ? 'Transferring'
                                        : server.status === 'installing'
                                        ? 'Installing'
                                        : server.status === 'restoring_backup'
                                        ? 'Restoring Backup'
                                        : 'Unavailable'}
                                </span>
                            </div>
                        ) : (
                            <Spinner size={'small'} />
                        )
                    ) : (
                        <React.Fragment>
                            <div css={tw`sm:flex flex-col hidden`}>
                                <p css={tw`font-header leading-tight text-xs md:text-sm text-gray-200`}>CPU Load</p>
                                <div css={tw`flex items-center`}>
                                    <div css={tw`flex items-center justify-center`}>
                                        <IconDescription $alarm={alarms.cpu}>
                                            {stats.cpuUsagePercent.toFixed(2)} %
                                        </IconDescription>
                                    </div>
                                    <p css={tw`text-xs text-neutral-200 text-center ml-1`}>/ {cpuLimit}</p>
                                </div>
                            </div>
                            <div css={tw`sm:flex flex-col hidden`}>
                                <p css={tw`font-header leading-tight text-xs md:text-sm text-gray-200`}>Memory Usage</p>
                                <div css={tw`flex items-center`}>
                                    <div css={tw`flex items-center justify-center`}>
                                        <IconDescription $alarm={alarms.memory}>
                                            {bytesToString(stats.memoryUsageInBytes)}
                                        </IconDescription>
                                    </div>
                                    <p css={tw`text-xs text-neutral-200 text-center ml-1`}>/ {memoryLimit}</p>
                                </div>
                            </div>
                            <div css={tw`sm:flex flex-col hidden`}>
                                <p css={tw`font-header leading-tight text-xs md:text-sm text-gray-200`}>Disk Usage</p>
                                <div css={tw`flex items-center`}>
                                    <div css={tw`flex items-center justify-center`}>
                                        <IconDescription $alarm={alarms.disk}>
                                            {bytesToString(stats.diskUsageInBytes)}
                                        </IconDescription>
                                    </div>
                                    <p css={tw`text-xs text-neutral-200 text-center ml-1`}>/ {diskLimit}</p>
                                </div>
                            </div>
                        </React.Fragment>
                    )}
                </div>
            </div>  
            <div className={'status-bar'} />
        </StatusIndicatorBox>
    );
};
