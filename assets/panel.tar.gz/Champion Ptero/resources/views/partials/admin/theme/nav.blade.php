@section('theme::nav')
    <div class="row">
        <div class="col-xs-12">
            <div class="nav-tabs-custom nav-tabs-floating">
                <ul class="nav nav-tabs">
                    <li @if($activeTab === 'theme_general')class="active"@endif><a href="{{ route('admin.theme') }}">General Settings</a></li>
                    <li @if($activeTab === 'theme_colors')class="active"@endif><a href="{{ route('admin.theme.colors') }}">Color Settings</a></li>
                </ul>
            </div>
        </div>
    </div>
@endsection
