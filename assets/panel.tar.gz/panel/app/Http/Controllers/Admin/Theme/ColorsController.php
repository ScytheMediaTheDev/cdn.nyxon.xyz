<?php

namespace Pterodactyl\Http\Controllers\Admin\Theme;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Http\Controllers\Controller;

class ColorsController extends Controller
{
    /**
     * ColorsController constructor.
     */
    public function __construct(
        private AlertsMessageBag $alert
    ) {
    }

    /**
     * Return the colors settings page.
     */
    public function index()
    {
        $settings = DB::table('theme_settings')->first();
        return view('admin.theme.colors', ['settings' => $settings]);
    }

    /**
     * Update the theme settings in database.
     */
    public function update(Request $request)
    {
        function hexToRgb($hex) {
            $hex = str_replace('#', '', $hex);
        
            if (strlen($hex) != 6) {
                return false;
            }
        
            $r = hexdec(substr($hex, 0, 2));
            $g = hexdec(substr($hex, 2, 2));
            $b = hexdec(substr($hex, 4, 2));
        
            return "$r, $g, $b";
        }

        $requestData = [
            'color_50' => hexToRgb($request->color_50),
            'color_100' => hexToRgb($request->color_100),
            'color_200' => hexToRgb($request->color_200),
            'color_300' => hexToRgb($request->color_300),
            'color_400' => hexToRgb($request->color_400),
            'color_500' => hexToRgb($request->color_500),
            'color_600' => hexToRgb($request->color_600),
            'color_700' => hexToRgb($request->color_700),
            'color_800' => hexToRgb($request->color_800),
            'color_900' => hexToRgb($request->color_900),
            'color_accent' => hexToRgb($request->color_accent),
            'color_box_border' => hexToRgb($request->color_box_border),
            'color_bttn_primary' => hexToRgb($request->color_bttn_primary),
            'color_h_bttn_primary' => hexToRgb($request->color_h_bttn_primary),
            'color_bttn_secondary' => hexToRgb($request->color_bttn_secondary),
            'color_h_bttn_secondary' => hexToRgb($request->color_h_bttn_secondary),
            'color_bttn_danger' => hexToRgb($request->color_bttn_danger),
            'color_h_bttn_danger' => hexToRgb($request->color_h_bttn_danger)
        ];

        $dataId = DB::table('theme_settings')->first()->id;
        DB::table('theme_settings')->where('id', '=', $dataId)->update($requestData);

        $this->alert->success('Colors Settings have been successfully updated.')->flash();
        return redirect()->route('admin.theme.colors');
    }
}
