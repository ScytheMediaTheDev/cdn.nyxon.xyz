Thank you for your purchase! If you need help or have a question feel free to join Support Server

Support Server: https://discord.gg/RNetuFxCGQ
Installation Guide: https://nidzo-docs.gitbook.io/championptero/installation-and-setup/how-to-install
FAQ: https://nidzo-docs.gitbook.io/championptero/other/faq

** You're not allowed to redistribute or leak this product **