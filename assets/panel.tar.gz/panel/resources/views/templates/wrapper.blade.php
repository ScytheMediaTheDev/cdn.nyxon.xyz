<!DOCTYPE html>
<html>
    @php
        use Illuminate\Support\Facades\DB;
        
        $themeData = DB::table('theme_settings')->first();
    @endphp
    <head>
        <title>{{ config('app.name', 'Pterodactyl') }}</title>

        @section('meta')
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <meta name="robots" content="noindex">
            <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
            <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
            <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
            <link rel="manifest" href="/favicons/manifest.json">
            <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
            <link rel="shortcut icon" href="/favicons/favicon.ico">
            <meta name="msapplication-config" content="/favicons/browserconfig.xml">
            <meta name="theme-color" content="#0e4688">
        @show

        @section('user-data')
            @if(!is_null(Auth::user()))
                <script>
                    window.PterodactylUser = {!! json_encode(Auth::user()->toVueObject()) !!};
                </script>
            @endif
            @if(!empty($siteConfiguration))
                <script>
                    window.SiteConfiguration = {!! json_encode($siteConfiguration) !!};
                </script>
            @endif
        @show
        <style>
            @import url('//fonts.googleapis.com/css?family=Rubik:300,400,500&display=swap');
            @import url('//fonts.googleapis.com/css?family=IBM+Plex+Mono|IBM+Plex+Sans:500&display=swap');

            <?php if ($themeData->nav_type == "sidebar"): ?>
                .topbar-navigation, .topbar-subnavigation, .topbar-account-subnav {
                    display: none;
                }
            <?php else: ?>
                .sidebar-navigation {
                    display: none;
                }
                .page-wrap-server, .page-wrap-dashboard {
                    padding-right: 0 !important;
                }
            <?php endif; ?>

            html {
                --accent-color: {{ $themeData->color_accent }};
                --boxes-hover-border: {{ $themeData->color_box_border }};
                --primary-bttn: {{ $themeData->color_bttn_primary }};
                --primary-bttn-hov: {{ $themeData->color_h_bttn_primary }};
                --secondary-bttn: {{ $themeData->color_bttn_secondary }};
                --secondary-bttn-hov: {{ $themeData->color_h_bttn_secondary }};
                --danger-bttn: {{ $themeData->color_bttn_danger }};
                --danger-bttn-hov: {{ $themeData->color_h_bttn_danger }};
                --color-50: {{ $themeData->color_50 }};
                --color-100: {{ $themeData->color_100 }};
                --color-200: {{ $themeData->color_200 }};
                --color-300: {{ $themeData->color_300 }};
                --color-400: {{ $themeData->color_400 }};
                --color-500: {{ $themeData->color_500 }};
                --color-600: {{ $themeData->color_600 }};
                --color-700: {{ $themeData->color_700 }};
                --color-800: {{ $themeData->color_800 }};
                --color-900: {{ $themeData->color_900 }};
            }

            body {
                background: url({{ $themeData->site_bg }}) no-repeat;
                background-position: center;
                background-size: cover;
            }
        </style>

        @yield('assets')

        @include('layouts.scripts')
    </head>
    <body class="{{ $css['body'] ?? 'bg-neutral-50' }}">
        @section('content')
            @yield('above-container')
            @yield('container')
            @yield('below-container')
        @show
        @section('scripts')
            {!! $asset->js('main.js') !!}
        @show
    </body>
</html>
