@extends('layouts.admin')
@include('partials/admin.theme.nav', ['activeTab' => 'theme_colors'])

@section('title')
    Colors Settings
@endsection

@php

function rgbToHex($color) {
    $rgbArray = explode(', ', $color);
    list($red, $green, $blue) = $rgbArray;

    $red = max(0, min(255, (int)$red));
    $green = max(0, min(255, (int)$green));
    $blue = max(0, min(255, (int)$blue));

    $hex = sprintf("#%02x%02x%02x", $red, $green, $blue);

    return $hex;
}

@endphp

@section('content-header')
    <h1>Colors Settings<small>Change Theme Colors to your liking.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Theme</li>
    </ol>
@endsection

@section('content')
    @yield('theme::nav')
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Colors Settings</h3>
                </div>
                <form action="{{ route('admin.theme.colors.update') }}" method="POST">
                    <div class="box-body">
                        <div class="row">
                            <div class="col-md-4">
                                <label class="control-label">Color 50</label>
                                <div>
                                    <input type="color" class="form-control" name="color_50" @if($settings) value="{{ rgbToHex($settings->color_50) }}" @endif />
                                    <p class="text-muted"><small>Color used for text, brightest one.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Color 100</label>
                                <div>
                                    <input type="color" class="form-control" name="color_100" @if($settings) value="{{ rgbToHex($settings->color_100) }}" @endif />
                                    <p class="text-muted"><small>Color used for text, little bit more gray.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Color 200</label>
                                <div>
                                    <input type="color" class="form-control" name="color_200" @if($settings) value="{{ rgbToHex($settings->color_200) }}" @endif />
                                    <p class="text-muted"><small>Color used for text, darker gray, similar to background.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Color 300</label>
                                <div>
                                    <input type="color" class="form-control" name="color_300" @if($settings) value="{{ rgbToHex($settings->color_300) }}" @endif />
                                    <p class="text-muted"><small>Color used for text, lighter gray, some normal one, 300, 400 & 500 can even be same or similar.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Color 400</label>
                                <div>
                                    <input type="color" class="form-control" name="color_400" @if($settings) value="{{ rgbToHex($settings->color_400) }}" @endif />
                                    <p class="text-muted"><small>Color used for text, also lighter gray, 300, 400 & 500 can even be same or similar.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Color 500</label>
                                <div>
                                    <input type="color" class="form-control" name="color_500" @if($settings) value="{{ rgbToHex($settings->color_500) }}" @endif />
                                    <p class="text-muted"><small>Color used for text, also lighter gray, 300, 400 & 500 can even be same or similar.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Color 600</label>
                                <div>
                                    <input type="color" class="form-control" name="color_600" @if($settings) value="{{ rgbToHex($settings->color_600) }}" @endif />
                                    <p class="text-muted"><small>'Third' Color, used in e.g. Sidebar, Input Fields BG etc.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Color 700</label>
                                <div>
                                    <input type="color" class="form-control" name="color_700" @if($settings) value="{{ rgbToHex($settings->color_700) }}" @endif />
                                    <p class="text-muted"><small>'Secondary' Color, used in e.g. StatBlocks, BG of Boxes etc.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Color 800</label>
                                <div>
                                    <input type="color" class="form-control" name="color_800" @if($settings) value="{{ rgbToHex($settings->color_800) }}" @endif />
                                    <p class="text-muted"><small>'Dark' Color, used for Site Background and some other places.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Color 900</label>
                                <div>
                                    <input type="color" class="form-control" name="color_900" @if($settings) value="{{ rgbToHex($settings->color_900) }}" @endif />
                                    <p class="text-muted"><small>'Dark' Color, for the same as 'Color 800'.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Accent Color</label>
                                <div>
                                    <input type="color" class="form-control" name="color_accent" @if($settings) value="{{ rgbToHex($settings->color_accent) }}" @endif />
                                    <p class="text-muted"><small>Accent color used on sidebar active & other places.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Boxes Hover Border</label>
                                <div>
                                    <input type="color" class="form-control" name="color_box_border" @if($settings) value="{{ rgbToHex($settings->color_box_border) }}" @endif />
                                    <p class="text-muted"><small>Border on hover of boxes.</small></p>
                                </div>
                            </div>
                            {{-- BUTTON COLORS --}}
                            <div class="col-md-4">
                                <label class="control-label">Primary Button</label>
                                <div>
                                    <input type="color" class="form-control" name="color_bttn_primary" @if($settings) value="{{ rgbToHex($settings->color_bttn_primary) }}" @endif />
                                    <p class="text-muted"><small>Color of the Primary Button.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Primary Button Hover</label>
                                <div>
                                    <input type="color" class="form-control" name="color_h_bttn_primary" @if($settings) value="{{ rgbToHex($settings->color_h_bttn_primary) }}" @endif />
                                    <p class="text-muted"><small>Hover Color of the Primary Button.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Secondary Button</label>
                                <div>
                                    <input type="color" class="form-control" name="color_bttn_secondary" @if($settings) value="{{ rgbToHex($settings->color_bttn_secondary) }}" @endif />
                                    <p class="text-muted"><small>Color of the Secondary Button.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Secondary Button Hover</label>
                                <div>
                                    <input type="color" class="form-control" name="color_h_bttn_secondary" @if($settings) value="{{ rgbToHex($settings->color_h_bttn_secondary) }}" @endif />
                                    <p class="text-muted"><small>Hover Color of the Secondary Button.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Danger Button</label>
                                <div>
                                    <input type="color" class="form-control" name="color_bttn_danger" @if($settings) value="{{ rgbToHex($settings->color_bttn_danger) }}" @endif />
                                    <p class="text-muted"><small>Color of the Danger Button.</small></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <label class="control-label">Danger Button Hover</label>
                                <div>
                                    <input type="color" class="form-control" name="color_h_bttn_danger" @if($settings) value="{{ rgbToHex($settings->color_h_bttn_danger) }}" @endif />
                                    <p class="text-muted"><small>Hover Color of the Danger Button.</small></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
