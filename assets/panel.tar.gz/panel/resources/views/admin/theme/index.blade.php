@extends('layouts.admin')
@include('partials/admin.theme.nav', ['activeTab' => 'theme_general'])

@section('title')
    Theme Settings
@endsection

@section('content-header')
    <h1>Theme Settings<small>Change General Theme Settings to your liking.</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">Admin</a></li>
        <li class="active">Theme</li>
    </ol>
@endsection

@section('content')
    @yield('theme::nav')
    <div class="row">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Theme Settings</h3>
                </div>
                <form action="{{ route('admin.theme.update') }}" method="POST">
                    <div class="box-body">
                        <div class="row">
                            <div class="form-group col-md-4">
                                <label class="control-label">Navigation Type</label>
                                <div>
                                    <select class="form-control" name="nav_type">
                                        <option value="sidebar" @if($settings->nav_type == "sidebar") selected @endif>Sidebar</option>
                                        <option value="navbar" @if($settings->nav_type == "navbar") selected @endif>Navbar (Topbar)</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label class="control-label">Site Background</label>
                                <div>
                                    <input id="logo" type="text" class="form-control" name="site_bg" @if($settings) value="{{ $settings->site_bg }}" @endif />
                                    <p class="text-muted"><small>Background image of the whole site (except of login), if none then color will be used.</small></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-footer">
                        {!! csrf_field() !!}
                        <button type="submit" class="btn btn-sm btn-primary pull-right">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
