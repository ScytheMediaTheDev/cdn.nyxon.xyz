import * as React from 'react';
import { useState, useEffect } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCogs, faLayerGroup, faSignOutAlt, faEllipsisH, faUser, faUserCircle } from '@fortawesome/free-solid-svg-icons';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import DropdownMenu, { DropdownButtonRow } from '@/components/elements/DropdownMenu';
import SearchContainer from '@/components/dashboard/search/SearchContainer';
import tw, { theme } from 'twin.macro';
import styled from 'styled-components/macro';
import http from '@/api/http';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import Tooltip from '@/components/elements/tooltip/Tooltip';
import Avatar from '@/components/Avatar';

const RightNavigation = styled.div`
    & > a,
    > .search-navbar,
    & > button {
        ${tw`flex items-center h-full no-underline text-neutral-300 px-6 cursor-pointer`};

        &:active,
        &:hover {
            ${tw`text-neutral-100 bg-gray-600`};
        }

        &:active,
        &:hover,
        &.active {
            border-bottom: 2px solid rgb(var(--accent-color));
        }
    }
`;

const DropdownStyle = styled.div`
    ${tw`h-[75%] flex ml-6`};

    & .navigation-link {
        ${tw`flex items-center gap-3 bg-gray-600 h-full rounded-lg w-max no-underline text-neutral-300 px-4 cursor-pointer`};

        &:hover {
            ${tw`transition-colors duration-150 hover:text-neutral-100`};
        }
    }
`;

export default () => {
    const name = useStoreState((state: ApplicationStore) => state.settings.data!.name);
    const rootAdmin = useStoreState((state: ApplicationStore) => state.user.data!.rootAdmin);
    const logo = useStoreState((state: ApplicationStore) => state.settings.data!.logo);
    const [isLoggingOut, setIsLoggingOut] = useState(false);

    const onTriggerLogout = () => {
        setIsLoggingOut(true);
        http.post('/auth/logout').finally(() => {
            // @ts-expect-error this is valid
            window.location = '/';
        });
    };

    return (
        <div className={'topbar-navigation w-full top-0 z-[49] bg-neutral-700 overflow-x-auto'}>
            <SpinnerOverlay visible={isLoggingOut} />
            <div className={'mx-auto w-full flex items-center h-[3.5rem] max-w-[1300px]'}>
                <div id={'logo'} className={'flex flex-1 mr-6 md:mr-0 pl-4 md:pl-0'}>
                    <Link className={'max-w-fit block'} to={'/'}>
                        <img className={'h-12 max-w-none'} src={logo || 'https://cdn.pterodactyl.io/logos/new/pterodactyl_logo_transparent.png'} />
                    </Link>
                </div>
                <RightNavigation className={'flex h-full items-center justify-center pr-4 md:pr-0'}>
                    <SearchContainer />
                    <Tooltip css={tw`z-50`} placement={'bottom'} content={'Dashboard'}>
                        <NavLink to={'/'} exact>
                            <FontAwesomeIcon icon={faLayerGroup} />
                        </NavLink>
                    </Tooltip>
                    <DropdownStyle>
                        <DropdownMenu
                            renderToggle={(onClick) => (
                                <Tooltip css={tw`z-50`} placement={'bottom'} content={'Account'}>
                                        <button
                                            className={'navigation-link'}
                                            onClick={onClick}                
                                            css={tw`text-gray-200 h-full`}
                                        >
                                            <FontAwesomeIcon icon={faUserCircle} />
                                            <span>My Account</span>
                                        </button>
                                </Tooltip>
                            )}
                        >
                            <div css={tw`text-sm`}>
                                <NavLink to={'/account'}>
                                    <DropdownButtonRow>
                                        <FontAwesomeIcon fixedWidth icon={faUser} css={tw`text-xs`} />
                                        <span css={tw`ml-2`}>My Account</span>
                                    </DropdownButtonRow>
                                </NavLink>
                            </div>
                            {rootAdmin && (
                                <div css={tw`text-sm`}>
                                    <a href={'/admin'}>
                                        <DropdownButtonRow>
                                                <FontAwesomeIcon fixedWidth icon={faCogs} css={tw`text-xs`} />
                                                <span css={tw`ml-2`}>Administration</span>
                                        </DropdownButtonRow>
                                    </a>
                                </div>
                            )}
                            <div css={tw`text-sm hover:text-red-500`}>
                                <DropdownButtonRow onClick={onTriggerLogout}>
                                    <FontAwesomeIcon fixedWidth icon={faSignOutAlt} css={tw`text-xs`} />
                                    <span css={tw`ml-2`}>Sign Out</span>
                                </DropdownButtonRow>
                            </div>
                        </DropdownMenu>
                    </DropdownStyle>
                </RightNavigation>
            </div>
        </div>
    );
};
