import styled from 'styled-components/macro';
import tw, { theme } from 'twin.macro';

const SubNavigation = styled.div`
    ${tw`w-full grid sticky md:relative top-0 z-[48] overflow-x-auto`};

    & > div {
        ${tw`flex items-center text-sm mx-auto px-2`};
        max-width: 1200px;

        & > a,
        & > div {
            ${tw`inline-block py-3 mb-1 px-4 text-neutral-300 no-underline whitespace-nowrap transition-all duration-150`};

            & > span {
                ${tw`ml-2`};
            }

            &:not(:first-of-type) {
                ${tw`ml-2`};
            }

            &:hover {
                ${tw`text-neutral-100`};
            }

            &:active,
            &.active {
                ${tw`text-neutral-100`};
                border-bottom: 2px solid rgb(var(--accent-color));
            }
        }
    }
`;

export default SubNavigation;
